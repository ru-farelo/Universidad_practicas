#include "util.h"
#include "matriz.h"
#include "cola.h"

void prim(matriz m, int n, cola* aristas);
