#include "util.h"
#include "matriz.h"

void dijkstra_normal(matriz m, int n, int *distancias);
