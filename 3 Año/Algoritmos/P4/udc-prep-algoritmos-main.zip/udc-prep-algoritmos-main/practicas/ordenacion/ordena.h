#include "util.h"
#include "monticulo.h"

#define UMBRAL 1

void ordena_seleccion(int v[], int n);
void ordena_shell(int v[], int n);
void ordena_insercion(int v[], int n);
void ordena_rapida(int v[], int n);
void ordena_fusion(int v[], int n);
