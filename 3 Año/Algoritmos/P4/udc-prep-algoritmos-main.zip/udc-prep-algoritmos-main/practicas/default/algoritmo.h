#include "util.h"

void funcion_algoritmo(int v[], int n);