#include "algoritmo.h"

void funcion_algoritmo(int v[], int n) {
    int i, acc = 0;
    for (i = 0; i < n; i++) {
        acc += v[i];
    }
}
