#include "util.h"
#include "monticulo.h"

int kesimo_mayor(int v[], int n, int k);
