# Fibonacci

> Página 33

```pseudo
función Fibonacci (n)
    si n < 2 entonces devolver n
    si no devolver Fibonacci(n - 1) + Fibonacci (n - 2)
```
