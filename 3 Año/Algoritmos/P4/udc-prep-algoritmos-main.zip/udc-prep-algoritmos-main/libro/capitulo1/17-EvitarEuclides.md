# EvitarEuclides

> Página 17

```pseudo
función EvitarEuclides (P : conjunto de enteros)
{ El argumento P debería ser un conjunto de primos no vacío finito }
    x ← el mayor elemento de P
    repetir x ← x + 1 hasta que x es primo
    devolver x
```
