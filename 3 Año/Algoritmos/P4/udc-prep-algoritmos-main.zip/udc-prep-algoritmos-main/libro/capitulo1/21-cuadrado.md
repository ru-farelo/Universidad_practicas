# cuadrado

> Página 21

```pseudo
función cuadrado (n)
    si n = 0 entonces devolver 0
    si no devolver 2n + cuadrado(n - 1) - 1
```
