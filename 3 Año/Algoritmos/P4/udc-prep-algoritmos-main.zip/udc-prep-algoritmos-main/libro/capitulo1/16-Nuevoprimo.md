# Nuevoprimo

> Página 16

```pseudo
función Nuevoprimo (P : conjunto de enteros)
{ El argumento P debería ser un conjunto de primos no vacío finito }
    x ← producto de los elementos de P
    y ← x + 1
    d ← 1
    repetir d ← d + 1 hasta que d divide a y
    devolver d
```
