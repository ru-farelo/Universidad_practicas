# Capítulo 1: Preeliminares

- [Nuevoprimo](16-Nuevoprimo.md)
- [EvitarEuclides](17-EvitarEuclides.md)
- [cuadrado](21-cuadrado.md)
- [Fibonacci](33-Fibonacci.md)
