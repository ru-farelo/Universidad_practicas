# Sum

> Página 75

```pseudo
función Sum (n)
{ Calcula la suma de los enteros de 1 a n }
    sum ← 0
    para i ← 1 hasta n hacer
        sum ← sum + 1
    devolver sum
```
