# Wilson

> Página 74

```pseudo
función Wilson (n)
{ Proporciona verdadero si y sólo si n es primo, n > 1 }
    si n divide (n - 1)! + 1 entonces devolver verdadero
    si no devolver falso
```
