# mcd

> Página 82

```pseudo
función mcd (m, n)
    i ← min(m, n) + 1
    repetir i ← i - 1 hasta que i divide exactamente tanto a m como a n
    devolver i
```
