# Capítulo 2: Algoritmia elemental

- [insertar](71-insertar.md)
- [seleccionar](71-seleccionar.md)
- [Wilson](74-Wilson.md)
- [Fibonacci](75-Fibonacci.md)
- [Sum](75-Sum.md)
- [casilla](80-casilla.md)
- [mcd](82-mcd.md)
- [Euclides](83-Euclides.md)
- [Fibrec](83-Fibrec.md)
- [Fibiter](84-Fibiter.md)
