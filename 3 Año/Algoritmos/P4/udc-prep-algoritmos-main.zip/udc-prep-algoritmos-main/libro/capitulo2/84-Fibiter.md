# Ficiter

> Página 84

```pseudo
función Fibiter (n)
    i ← 1; j ← 0
    para k ← 1 hasta n hacer
        j ← i + j
        i ← j - i
    devolver j
```
