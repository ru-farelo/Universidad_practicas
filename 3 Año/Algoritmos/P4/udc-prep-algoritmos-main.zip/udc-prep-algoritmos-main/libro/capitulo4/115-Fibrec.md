# Fibrec

> Página 115

```pseudo
función Fibrec (n)
    si n < 2 entonces devolver n
    sino devolver Fibrec (n - 1) + Fibrec (n - 2)
```
