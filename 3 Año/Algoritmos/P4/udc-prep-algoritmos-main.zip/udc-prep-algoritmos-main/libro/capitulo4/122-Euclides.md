# Euclides

> Página 122

```pseudo
función Euclides (m, n)
    mientras m > 0 hacer
        t ← m
        m ← n mod m
        n ← t
    devolver n
```
