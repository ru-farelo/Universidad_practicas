# Capítulo 4: Análisis de algoritmos

- [Fibiter](113-Fibiter.md)
- [Fibrec](115-Fibrec.md)
- [Búsqueda binaria](116-Búsqueda%20binaria.md)
- [selección](120-selección.md)
- [inserción](121-inserción.md)
- [Euclides](122-Euclides.md)
- [Hanoi](124-Hanoi.md)
- [contar](128-contar.md)
