# VA-Practicas
Autor: Rubén Fernández Farelo
Practicas de VA - P1 

P1.py -> Funciones de la practica 1

Imagenes.py -> Funciones para el cargado y visualización de imagenes. También se usara para implementar las funciones auxiliares

Test.py ->Test de  las funciones implementadas en la practica 1 

main.py -> Main principal para ejecutar las setencias para comprobar el correcto funcionamiento de las funciones de la practica 1 con sus test

Ejecución -> python3 main.py o python main.py